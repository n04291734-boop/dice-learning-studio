DICE LAB / LEARNING STUDIO

A separate educational webpage. It does not access or change your existing Dice Lab dashboard, live games, or stored roll history. The dice experiment generates synthetic classroom samples only.

Offline: open index.html in a browser. Built-in lessons and the fair-dice simulator work without AI.

Optional local AI:
1. Install Ollama from https://ollama.com/ on a supported computer. Start Ollama.
2. In Terminal, download ONE supported local model. Example:
   ollama pull qwen2.5:1.5b
   Other optional models: ollama pull gemma2:2b ; ollama pull mistral:7b
   Larger models require more memory. These commands download model files; no cloud AI account or API key is required for local inference.
3. Install Python 3 if needed. In Terminal, enter the extracted dice-learning-studio folder (type cd followed by a space, drag the folder into Terminal, then press Enter).
4. Run: python3 server.py
5. Open http://127.0.0.1:8765 in your browser. Select the installed model, check connection, select a classroom topic, and click Explain with local AI.
6. Stop the local server with Control+C.

The server binds to loopback only. It sends fixed classroom lesson prompts to Ollama on loopback. It has no API keys, live data inputs or general-purpose chat endpoint. Do not expose it to the public internet. Local models can make mistakes. No live Ollama model was available in the build environment for an end-to-end AI test.
