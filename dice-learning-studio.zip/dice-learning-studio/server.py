"""Local, fixed-topic probability tutor. No live data or external game integration."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, urllib.request, urllib.error

ROOT = Path(__file__).resolve().parent
MODELS = ('qwen2.5:1.5b', 'gemma2:2b', 'mistral:7b')
TOPICS = {
 'independence': 'Explain independent outcomes using an ordinary fair six-sided classroom die. Explain why a previous outcome does not change the next outcome probability.',
 'sample': 'Explain sample size and sampling variability using a classroom experiment rolling a fair die 30 times versus 3000 times.',
 'entropy': 'Explain Shannon entropy for a six-category distribution, with the formula and what normalized entropy measures. Explain why marginal entropy does not prove independence.',
 'frequency': 'Explain the difference between observed relative frequency and theoretical probability using a simple classroom example.',
 'streaks': 'Explain why streaks naturally occur in independent classroom dice experiments and why a streak is not evidence that an outcome is due.',
 'chi': 'Explain the chi-square goodness-of-fit test for a fair classroom die, including expected counts and the limitation that it does not establish independence.'
}

def request_local(path, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request('http://127.0.0.1:11434' + path, data=data, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=120 if body else 3) as response:
        return json.loads(response.read())

class Handler(BaseHTTPRequestHandler):
    def reply(self, status, obj):
        payload = json.dumps(obj).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(payload))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(payload)
    def do_GET(self):
        if self.path == '/':
            payload=(ROOT/'index.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(payload))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(payload)
        elif self.path == '/api/status':
            try:
                data=request_local('/api/tags')
                self.reply(200,{'connected':True,'models':[m for m in MODELS if m in [x.get('name') for x in data.get('models',[])]]})
            except (OSError, ValueError): self.reply(200,{'connected':False,'models':[]})
        else: self.reply(404,{'error':'Not found'})
    def do_POST(self):
        if self.path != '/api/explain': return self.reply(404,{'error':'Not found'})
        # Require same origin and JSON, and accept only fixed topics and local models.
        if self.headers.get('Origin') not in ('http://127.0.0.1:8765','http://localhost:8765') or self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            return self.reply(403,{'error':'Open the local learning page to make a request.'})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=2048: raise ValueError()
            obj=json.loads(self.rfile.read(n)); model=obj['model']; topic=obj['topic']
            if model not in MODELS or topic not in TOPICS: raise ValueError()
        except (ValueError,TypeError,KeyError): return self.reply(400,{'error':'Select a supported model and lesson.'})
        try:
            result=request_local('/api/chat',{'model':model,'stream':False,'messages':[{'role':'system','content':'You are a concise, age-appropriate classroom mathematics tutor. Explain only the requested educational concept. Do not give predictions, betting advice, gambling strategies, or live game analysis. Use at most 160 words and plain text.'},{'role':'user','content':TOPICS[topic]}],'options':{'temperature':0.2,'num_predict':300}})
            answer=result.get('message',{}).get('content','').strip()
            if not answer: raise ValueError('empty answer')
            self.reply(200,{'answer':answer,'model':model})
        except (OSError,ValueError): self.reply(503,{'error':'Local model unavailable. Check Ollama and download the selected model; the offline lesson still works.'})

if __name__=='__main__':
    print('Dice Lab Learning Studio: http://127.0.0.1:8765', flush=True)
    ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
